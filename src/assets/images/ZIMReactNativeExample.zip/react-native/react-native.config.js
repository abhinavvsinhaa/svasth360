module.exports = {
    dependencies: {
        'local-rn-library': {
            root: '/root/libraries',
        },
    },
};
