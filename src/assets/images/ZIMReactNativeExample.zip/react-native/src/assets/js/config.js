export const avatarPrefix = "https://storage.zego.im/zim/example/web/assets/"

export const appConfig = {
  appID: 0, // AppID - type: number
  appSign: "", // AppSign - type: 64 byte length string
}
